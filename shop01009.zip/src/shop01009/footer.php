<footer id="footer_area"><hr>
  <ul class="navi">
    <li>01組 009番 梶原健成</li>
  </ul>
<br>
</footer>
